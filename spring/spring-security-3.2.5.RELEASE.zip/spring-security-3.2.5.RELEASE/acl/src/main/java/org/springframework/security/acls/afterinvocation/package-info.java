/**
 * After-invocation providers for collection and array filtering. Consider using a {@code PostFilter} annotation in
 * preference.
 */
package org.springframework.security.acls.afterinvocation;

