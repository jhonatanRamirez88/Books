/**
 * Basic implementation of access control lists (ACLs) interfaces.
 */
package org.springframework.security.acls.domain;

