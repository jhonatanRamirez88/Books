/**
 * JDBC-based persistence of ACL information
 */
package org.springframework.security.acls.jdbc;

