/**
 * Security namespace support for LDAP authentication.
 */
package org.springframework.security.config.ldap;

