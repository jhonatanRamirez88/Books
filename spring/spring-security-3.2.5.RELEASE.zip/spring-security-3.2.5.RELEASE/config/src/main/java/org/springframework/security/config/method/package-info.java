/**
 * Support for parsing of the &lt;global-method-security&gt; and &lt;intercept-methods&gt; elements.
 */
package org.springframework.security.config.method;

