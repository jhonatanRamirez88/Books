/**
 * Support classes for the Spring Security namespace. None of the code in these packages should be used directly
 * in applications.
 */
package org.springframework.security.config;

