/**
 * Role hierarchy implementation.
 */
package org.springframework.security.access.hierarchicalroles;
