/**
 * Enforces security for AOP Alliance <code>MethodInvocation</code>s, such as via Spring AOP.
 */
package org.springframework.security.access.intercept.aopalliance;
