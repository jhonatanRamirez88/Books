/**
 * Provides {@code SecurityMetadataSource} implementations for securing Java method invocations via different
 * AOP libraries.
 */
package org.springframework.security.access.method;
