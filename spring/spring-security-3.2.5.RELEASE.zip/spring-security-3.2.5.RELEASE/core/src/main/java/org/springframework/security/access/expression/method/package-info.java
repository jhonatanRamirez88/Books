/**
 * Implementation of expression-based method security.
 *
 * @since 3.0
 */
package org.springframework.security.access.expression.method;
