/**
 * Authentication processing mechanisms which respond to the submission of authentication
 * credentials using CAS.
 */
package org.springframework.security.cas.web.authentication;
