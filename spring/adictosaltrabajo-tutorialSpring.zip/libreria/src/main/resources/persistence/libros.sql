CREATE  TABLE LIBRO (
  id INT NOT NULL ,
  titulo VARCHAR(45) NOT NULL ,
  isbn VARCHAR(50) ,
  autor VARCHAR(50) ,
  PRIMARY KEY (id) );
  
  
INSERT INTO libro VALUES ('0','Java','1234','Manuel');
INSERT INTO libro VALUES ('1','C','4567','Ricardo');
INSERT INTO libro VALUES ('2','Python','1010','Jaime');
  
